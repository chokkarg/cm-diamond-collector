const message = text => {
  chrome.runtime.sendMessage(text)
}

const reload = () => {
  message('reloading')
  location.reload()
}

const checkCandy = () => {
  const inputElement = document.querySelectorAll('button.x0o17e-0')[0]
  const divElement = document.querySelectorAll('div.x0o17e-0')[0]
  const beforeCollect = document.getElementsByName('Collect Diamonds')[2];
  const afterCollect = document.getElementsByName('to collect');
  const buttonText =  inputElement.textContent;

  if (buttonText.includes('Collect Diamonds')) {
    message('clicking')
    inputElement.click()
    setTimeout(reload, 50000)
  } else if (buttonText.includes('to collect')) {    
    if (buttonText.includes('0:00:00')) {
      reload()
    }
  } else {
    message('could not find expected elements')
  }

  // if (inputElement.contains('Collect Diamonds')[2]) {
  //   message('clicking')
  //   inputElement.click()
  //   setTimeout(reload, 5000)
  // }
  // else if (divElement) {
  //   message('scouting')

  //   const cooldown = document.getElementById('next-daily-reward-countdown-timer')
  //   if (cooldown.innerHTML === '0:00:00') {
  //     reload()
  //   }
  // }
  // else {
  //   message('could not find expected elements')
  // }

  // if(beforeCollect){
  //   beforeCollect.click()
  //   setTimeout(reload, 5000)
  // }
  // else if(afterCollect){
  //   if(afterCollect.innerHTML === '0:00:00'){
  //     reload()
  //   }
  // } else {
  //   message('could not find expected elements')
  // }
}

setInterval(checkCandy, 3600 * 1000)
checkCandy()
