import shutil
shutil.make_archive('cm-diamond-collector', 'zip', 'src')